
public class Calculator {
	
	//add
	public int add (int a, int b) {
		 return a + b;
	}
	// substract
	public int substract(int a, int b) {
		return a - b;
	}
	//multiple
	public int multiple(int a, int b) {
		return a * b;
	}
	//divide
	public int divide (int a, int b) {
		return a / b;
	}


}
